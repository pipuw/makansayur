// Menampilkan modal konfirmasi pembayaran
document.getElementById('submitButton').addEventListener('click', function() {
    const nama = document.getElementById('nama').value;
    const alamat = document.getElementById('alamat').value;
    const kota = document.getElementById('kota').value;
    const kodepos = document.getElementById('kodepos').value;
    const nomorhp = document.getElementById('nomorhp').value;
    const metodePengiriman = document.querySelector('input[name="pengiriman"]:checked').value;
    const pilihanKurir = metodePengiriman === 'Kurir' ? document.getElementById('pilihanKurir').value : '-';
    const totalPembelanjaan = "Rp 23.000"; // Simulasi total pembelanjaan

    document.getElementById('modalNama').textContent = nama;
    document.getElementById('modalAlamat').textContent = alamat;
    document.getElementById('modalKota').textContent = kota;
    document.getElementById('modalKodepos').textContent = kodepos;
    document.getElementById('modalNomorhp').textContent = nomorhp;
    document.getElementById('modalPengiriman').textContent = metodePengiriman;
    document.getElementById('modalKurir').textContent = pilihanKurir;
    document.getElementById('modalTotal').textContent = totalPembelanjaan;

    document.getElementById('paymentPopup').style.display = 'flex';
});

// Konfirmasi pembayaran dan menampilkan kwitansi
document.getElementById('confirmPayment').addEventListener('click', function() {
    document.getElementById('paymentPopup').style.display = 'none';
    document.getElementById('kwitansiModal').style.display = 'flex';
});

// Menutup modal konfirmasi pembayaran
document.getElementById('closePopup').addEventListener('click', function() {
    document.getElementById('paymentPopup').style.display = 'none';
});

// Menutup modal kwitansi ketika pengguna mengklik di luar modal
window.onclick = function(event) {
    if (event.target == document.getElementById('kwitansiModal')) {
        document.getElementById('kwitansiModal').style.display = 'none';
    }
};

// Cetak kwitansi
document.getElementById('printReceipt').addEventListener('click', function() {
    window.print();
});
