<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$password = "";
$database = "makansayur";

$connection = mysqli_connect($host, $user, $password, $database);

// Cek koneksi
if (!$connection) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// Query untuk mengambil data penjualan
$query = "SELECT * FROM sales ORDER BY sale_date DESC";
$result = mysqli_query($connection, $query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Penjualan</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center">Laporan Penjualan</h2>
    
    <table class="table table-bordered mt-3">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Nama Produk</th>
                <th>Kuantitas</th>
                <th>Harga</th>
                <th>Total</th>
                <th>Tanggal Penjualan</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['product_name']; ?></td>
                    <td><?php echo $row['quantity']; ?></td>
                    <td><?php echo number_format($row['price'], 2); ?></td>
                    <td><?php echo number_format($row['total'], 2); ?></td>
                    <td><?php echo date('d-m-Y H:i', strtotime($row['sale_date'])); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php
// Tutup koneksi
mysqli_close($connection);
?>
